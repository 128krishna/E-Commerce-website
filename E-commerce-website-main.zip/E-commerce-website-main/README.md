# E-commerce-website
This is the project  related to e-commerce  solution  and find the seamless process for storing  data in database using django python framework.
